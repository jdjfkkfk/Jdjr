import Media from './Media';

export default interface Movie extends Media {
  runtime: number;
}
